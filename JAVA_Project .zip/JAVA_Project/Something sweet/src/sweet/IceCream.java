package sweet;

import java.util.Hashtable;
import java.util.Vector;


/**
 * A data class whose instances represent a single IceCream.
 * Contains all the possible IceCream data on class level.
 */
public class IceCream {
	
	/**
	 * Class level Hashtable containing all flavour names as keys and prices as values.
	 */
	public final static Hashtable<String, Float> dataFlavours = new Hashtable<String, Float>() {
		{
			put("Strawberry", 5.50f);
			put("Vanilla", 4.50f);
			put("Chocolate", 7.50f);
			put("Punch", 9.50f);
			put("Orange", 9.50f);
			put("Cherry", 9.50f);
		}
	};

	/**
	 * Class level Hashtable containing all toping names as keys and prices as values.
	 */
	public final static Hashtable<String, Float> dataTopings = new Hashtable<String, Float>() {
		{
			put("Nothing", 0f);
			put("Chocolate", 7.50f);
			put("Caramel", 8.50f);
		}
	};
	
	/**
	 * Class level Hashtable containing all cone names as keys and prices as values.
	 */
	public final static Hashtable<String, Float> dataCones = new Hashtable<String, Float>() {
		{
			put("Cone", 7.50f);
			put("Paper cup", 7.50f);
			put("Glass", 10.50f);			
		}
	};
	
	// INSTANCE LEVEL
	Vector<String> flavours; // all flavour names as a Vector of strings
	String toping;  // toping name
	String cone;  // cone name
	float price;  // price calculated from the above.

	//------------------CONSTRUCTOR----------------------
	
	/**
	 * Creates a new IceCream with selected flavours (at least one must be present), toping and cane. Calculates the price.
	 * @param flavours Vector<String>
	 * @param toping String
	 * @param cone String
	 */
	public IceCream(Vector<String> flavours, String toping, String cone) {
		// check that at least one flavour is present
		if (flavours.size() == 0) {
			throw new java.lang.Error("At least one flavour must be present");
		}
		
		// check that all flavour names exist in class level data	
		for (int i=0; i<flavours.size(); i ++) {
			if (!dataFlavours.containsKey(flavours.get(i))) {
				throw new java.lang.Error("Unknown flavour");
			}
		}
		
		// check that toping name exists
		if (!dataTopings.containsKey(toping)) {
			throw new java.lang.Error("Unknown toping");
		}

		// check that cone name exists
		if (!dataCones.containsKey(cone)) {
			throw new java.lang.Error("Unknown cone");
		}
		
		// set the instance data
		this.flavours = flavours;
		this.toping = toping;
		this.cone = cone;

		// calculate the price for this IceCream
		calcPrice();

	}
	
	
	/**
	 * (Re)Calculates the price for this IceCream. Automatically called on flavours, toping or cone change. 
	 */
	public void calcPrice() {

		int flavourPrice = 0; // price for each flavour
		for (int i=0; i<flavours.size(); i ++) {
			flavourPrice += dataFlavours.get(flavours.get(i));
		}
		this.price = flavourPrice + dataTopings.get(toping) + dataCones.get(cone);		
	}

	@Override
	public String toString() {
		return "IceCream (price=" + price + "): made of " + flavours 
				+ " with " + toping + " as toping in a " + cone + ".\n";
	}
	
	/**
	 * Gets all the flavour names as an array of strings.
	 * @return String[]
	 */
	public static String[] getFlavourNames() {
		return dataFlavours.keySet().toArray(new String[dataFlavours.size()]);
	}
	
	/**
	 * Gets all the toping names as an array of strings.
	 * @return String[]
	 */
	public static String[] getTopingNames() {
		return dataTopings.keySet().toArray(new String[dataTopings.size()]);
	}
	
	/**
	 * Gets all the cone names as an array of strings.
	 * @return String[]
	 */
	public static String[] getConeNames() {
		return dataCones.keySet().toArray(new String[dataCones.size()]);
	}
	
	/**
	 * Get the Vector of strings representing all the flavour names in this IceCream
	 * @return Vector<String>
	 */
	public Vector<String> getFlavour() {
		return flavours;
	}
	
	/**
	 * Set the Vector of strings representing all the flavour names in this IceCream
	 * @param flavours Vector<String>
	 */
	public void setFlavour(Vector<String> flavours) {
		this.flavours = flavours;
		calcPrice();
	}

	/**
	 * Get the toping name for this IceCream.
	 * @return String
	 */
	public String getToping() {
		return toping;
	}

	/**
	 * Set the toping name for this IceCream.
	 * @param toping String
	 */
	public void setTopping(String toping) {
		this.toping = toping;
		calcPrice();
	}

	/**
	 * Get the cone name for this IceCream.
	 * @return String
	 */
	public String getCone() {
		return cone;
	}
	
	/**
	 * Set the toping name for this IceCream.
	 * @param toping String
	 */
	public void setCane(String cane) {
		this.cone = cane;
		calcPrice();
	}
}
