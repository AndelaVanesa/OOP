package sweet;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.MatteBorder;
/**
 * @author Anđela Vanesa Tuta
 * @version 1.0
 * @since 09/2020
 */

/**
 * Main window for SomethingSweet. This class creates IceCream instances and 
 * stores them for the current session. It then it can output all the created IceCream to a text file.
 */
public class SomethingSweet extends JFrame {
	// data
	Vector<IceCream> madeIceCreams; // keeps all the IceCreams made in this session.
	
	// main widgets
	
	FlavourPicker flavourPicker;  // custom input for multiple flavours	
	JComboBox<String> comboToping; // toping input
	JComboBox<String> comboCone;  // cone input
	JTextArea textOutput; // text window for displaying all the made IceCream
	JButton buttonMake;  // button that makes the IceCream 
	JButton buttonSaveText;  // button that saves the already made IceCream to a text file
	
	// SomethingSweet should be pretty (GUI components for the looks)	
	JPanel topingPanel; // used to create a title label for toping
	JPanel conePanel; // used to create a title label for cone
	
	
	/**
	 * The default constructor that creates the main window GUI.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public SomethingSweet() throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException  {
		// call the appropriate JFrame constructor i.e. call the constructor of the JFrame class with a single string
		super("SomethingSweet");
		
		// create a Vector for made IceCreams
		madeIceCreams = new Vector<IceCream>();
		
		// create the main widgets
		flavourPicker = new FlavourPicker();				
		comboToping = new JComboBox<String>(IceCream.getTopingNames());
		comboCone = new JComboBox<String>(IceCream.getConeNames());		
		textOutput = new JTextArea();
		buttonMake = new JButton("Make");
		buttonSaveText = new JButton("Save");
		
		// connect actions to buttons		
		buttonMake.addActionListener(new ActionListener() { // this is anonymous class, we create a new class on the fly that implements an ActionListener interface
			// ActionListener interface requires us to implement one method: actionPerformed(ActionEvent e)  
		    public void actionPerformed(ActionEvent e) {
		    	pushButtonMake();  // and we just connect the button push to pushButtonMake method 
		    }
		});
		
		buttonSaveText.addActionListener(new ActionListener() {   
		    public void actionPerformed(ActionEvent e) {
		    	try {  // must have try since pushButtonSaveToText may throw IOException
					pushButtonSaveToText();  // but otherwise just connect the button to pushButtonSaveToText 
				} catch (IOException ex) {					
					ex.printStackTrace();
				}
		    }
		});
				
		// add some of the input widgets to JPanels with labels		
		Dimension dimMaxCombo = new Dimension(500, 25);  // maximum size for panels with title and combo so they don't stretch too much		
		// add toping combo input to Panel with title
		topingPanel = new JPanel(new BorderLayout());		
		topingPanel.setBorder(BorderFactory.createTitledBorder("Toping"));
		topingPanel.add(comboToping);
		topingPanel.setMaximumSize(dimMaxCombo);
		topingPanel.setBackground(new Color(224, 255, 255));
		// add cone combo input to Panel with title
		conePanel = new JPanel(new BorderLayout());		
		conePanel.setBorder(BorderFactory.createTitledBorder("Cone"));
		conePanel.add(comboCone);
		conePanel.setMaximumSize(dimMaxCombo);
		conePanel.setBackground(new Color(245, 255, 250)); 
		
		
		// setup the window
		// setup the theme
		//UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 777, 631);
		setResizable(true); //  allow the window to be resized
		
		
			//contentPane.setLayout(null);
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2); // Java's object that centers the window 
		
		getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
		// add all the widgets to the window's contents
		
	
		getContentPane().add(flavourPicker);
		getContentPane().add(topingPanel);
		getContentPane().add(conePanel);
		getContentPane().add(new JSeparator()); // add a thin horizontal line
		getContentPane().add(buttonMake);
		getContentPane().add(textOutput);
		getContentPane().add(buttonSaveText);
		

		// show the window
		setVisible(true);
	}
	
	
	private void setBorder(MatteBorder matteBorder) {
		// TODO Auto-generated method stub
		
	}


	/**
	 * What happens when buttonMake is pushed. 
	 * Public so it may also be used by other code to simulate button press if needed. 
	 */
	public void pushButtonMake() {
		// check that at least one flavour is chosen
		Vector<String> flavours = flavourPicker.getChosenFlavors();
		if (flavours.size() == 0) {
			// complain to the user that no flavours are chosen
			JOptionPane.showMessageDialog(this, "At least one flavour must be chosen!", 
					"Flavour Error", JOptionPane.ERROR_MESSAGE);
		} else {
			// otherwise make the IceCream. Hurray! Success!!
			IceCream iceCream = makeIceCream();  // create the IceCream
			madeIceCreams.add(iceCream); // add the iceCream to the array of made IceCream instances 
			textOutput.append(iceCream.toString());  // add the text representation to the textOutput widget
		}
	}
	
	/**
	 * What happens when buttonSaveToText is pushed. 
	 * Public so it may also be used by other code to simulate button press if needed. 
	 */
	public void pushButtonSaveToText() throws IOException {		
		// create a "file dialog"
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Specify a file to save");   
		 
		// get the user choice through a "save dialog" i.e. a dialog asking for a new file, not an existing one
		int userSelection = fileChooser.showSaveDialog(this);
		 
		if (userSelection == JFileChooser.APPROVE_OPTION) {
		    File fileToSave = fileChooser.getSelectedFile();
		    saveToText(fileToSave.getAbsolutePath()); 
		}
	}
	
	/**
	 * Creates and returns the IceCream instance for the current input.
	 * @return IceCream 
	 */
	public IceCream makeIceCream() {		
    	IceCream iceCream = new IceCream(
			flavourPicker.getChosenFlavors(), 
			comboToping.getSelectedItem().toString(), // getSelectedItem returns Object that we then need to convert to string.
			comboCone.getSelectedItem().toString()
	    );
    	return iceCream;
	}
	
	/**
	 * Writes all created IceCreams to a text file.  
	 * @param path: the path to write to
	 * @throws IOException
	 */
	public void saveToText(String path) throws IOException {
		FileWriter writer = new FileWriter(path);  // open a file for writing
		for (int i=0; i<madeIceCreams.size(); i++) { // for every made IceCream
			writer.write(madeIceCreams.get(i).toString()); // write the string representation of an IceCream to file
		}
		writer.close();  // close the file
	};
	
	/** 
	 * Runs the application.
	 * @throws UnsupportedLookAndFeelException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException, UnsupportedLookAndFeelException {
		// Just instantiate this class. Constructor will take care of the rest.
		SomethingSweet sweet = new SomethingSweet(); 
	}

}
