package sweet;

import java.util.Vector;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JPanel;
import javax.swing.BorderFactory;
import javax.swing.JCheckBox;


/**
 * A set of checkboxes for getting a Vector of IceCream flavours.
 */
public class FlavourPicker extends JPanel {
	
	JCheckBox[] checkBoxes;  // internal array of checkboxes for easy access	
	
	/**
	 * Creates the flavour picker panel with all flavours represented as checkboxes.
	 */
	public FlavourPicker() {
		super();
		setLayout(new FlowLayout());
		
		// get all flavour names
		String[] flavours = IceCream.getFlavourNames();
		
		// create a new array of checkboxes with length equal to number of flavours
		checkBoxes = new JCheckBox[flavours.length];
				
		// create all the checkboxes
		JCheckBox checkBox;  // variable to hold current checkBox in the loop
		for (int i=0; i<flavours.length; i++) {
			checkBox = new JCheckBox(flavours[i], false);  // create the checkbox
			checkBoxes[i] = checkBox; // add the checkbox to the internal list of checkboxes
			add(checkBox);
		}
		
		// set the border with title around this panel
		setBorder(BorderFactory.createTitledBorder("Flavours"));
		setBackground(new Color(245, 255, 250));
		
	}
		
	/**
	 * Creates the Vector of strings containing all the currently selected flavour names. 
	 * @return Vector<string>
	 */
	public Vector<String> getChosenFlavors() {
		Vector<String> checked = new Vector<String>();
		
		JCheckBox checkBox;  // variable to hold current checkBox in the loop
		for (int i=0; i<checkBoxes.length; i++) {
			checkBox = checkBoxes[i]; // get the checkbox
			if (checkBox.isSelected()) {
				checked.add(checkBox.getText());
			}
		}
		
		return checked;
	}
	
}
